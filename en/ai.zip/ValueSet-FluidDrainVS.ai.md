# Fluid Drain Value Set - Patient Monitoring Outcome FHIR Implementation Guide v0.1.0

## ValueSet: Fluid Drain Value Set 

 
Valid UCUM units for drain fluid measurement 

 **References** 

* [Drain Fluid Observation](StructureDefinition-drain-fluid-observation.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "FluidDrainVS",
  "url" : "http://hl7belgium.org/fhir/patient-monitoring/ValueSet/FluidDrainVS",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.4.642.40.54.48.10"
  }],
  "version" : "0.1.0",
  "name" : "FluidDrainVS",
  "title" : "Fluid Drain Value Set",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-08T08:28:29+00:00",
  "publisher" : "HL7 Belgium",
  "contact" : [{
    "name" : "HL7 Belgium",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.com/committees"
    },
    {
      "system" : "email",
      "value" : "my-group@example.com"
    }]
  },
  {
    "name" : "Bob Smith",
    "telecom" : [{
      "system" : "email",
      "value" : "bobsmith@example.com",
      "use" : "work"
    }]
  }],
  "description" : "Valid UCUM units for drain fluid measurement",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE",
      "display" : "Belgium"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://unitsofmeasure.org",
      "concept" : [{
        "code" : "mL/d",
        "display" : "mL/d"
      }]
    }]
  }
}

```
